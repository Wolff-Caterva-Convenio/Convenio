"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";

export default function VenueDetailPage() {
  const { venue_id } = useParams();
  const router = useRouter();

  const API_BASE = useMemo(
    () => process.env.NEXT_PUBLIC_API_BASE || "http://127.0.0.1:9000",
    []
  );

  const [venue, setVenue] = useState(null);
  const [me, setMe] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [acceptRules, setAcceptRules] = useState(false);

  function getToken() {
    return localStorage.getItem("access_token");
  }

  function toDate(s) {
    if (!s) return null;
    const d = new Date(s + "T00:00:00");
    if (Number.isNaN(d.getTime())) return null;
    return d;
  }

  function nightsBetween(checkInStr, checkOutStr) {
    const a = toDate(checkInStr);
    const b = toDate(checkOutStr);
    if (!a || !b) return 0;
    const ms = b.getTime() - a.getTime();
    const days = Math.round(ms / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  }

  function centsToEur(cents) {
    if (typeof cents !== "number") return "0.00";
    return (cents / 100).toFixed(2);
  }

  function guestPriceFromNet(netCents) {
    if (typeof netCents !== "number") return 0;
    return Math.round(netCents / 0.83);
  }

  async function loadMeIfLoggedIn() {
    const token = getToken();
    if (!token) {
      setMe(null);
      return null;
    }

    const res = await fetch(`${API_BASE}/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      setMe(null);
      return null;
    }

    const data = await res.json();
    setMe(data);
    return data;
  }

  async function loadVenue(meData) {
    setVenue(null);
    setError("");

    try {
      const publicRes = await fetch(`${API_BASE}/venues/search`);
      if (!publicRes.ok) throw new Error(await publicRes.text());

      const publicList = await publicRes.json();
      const publicFound = publicList.find(
        (x) => String(x.id) === String(venue_id)
      );

      if (publicFound) {
        setVenue(publicFound);
        return;
      }

      const token = getToken();
      if (token && meData) {
        const mineRes = await fetch(`${API_BASE}/venues/mine`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!mineRes.ok) throw new Error(await mineRes.text());

        const mineList = await mineRes.json();
        const mineFound = mineList.find(
          (x) => String(x.id) === String(venue_id)
        );

        if (mineFound) {
          setVenue(mineFound);
          return;
        }
      }

      setError("Venue not found.");
      setVenue(null);
    } catch (e) {
      setError(e?.message || String(e));
      setVenue(null);
    }
  }

  useEffect(() => {
    async function run() {
      const meData = await loadMeIfLoggedIn().catch(() => null);
      await loadVenue(meData).catch(() => {});
    }

    run();
  }, [venue_id]);

  async function bookAndPay() {
    setError("");

    const token = getToken();
    if (!token) {
      router.push(`/login?next=/venues/${venue_id}`);
      return;
    }

    if (!venue) {
      setError("Venue not found.");
      return;
    }

    if (!checkIn || !checkOut) {
      setError("Please select both check-in and check-out dates.");
      return;
    }

    const n = nightsBetween(checkIn, checkOut);
    if (n <= 0) {
      setError("Check-out must be after check-in.");
      return;
    }

    if (venue.minimum_nights && n < venue.minimum_nights) {
      setError(`Minimum stay is ${venue.minimum_nights} night(s).`);
      return;
    }

    if (!acceptRules) {
      setError("Please accept venue rules + GTC before paying.");
      return;
    }

    setBusy(true);

    try {
      const bookingRes = await fetch(`${API_BASE}/venues/${venue_id}/bookings`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          check_in: checkIn,
          check_out: checkOut,
        }),
      });

      if (!bookingRes.ok) throw new Error(await bookingRes.text());
      const booking = await bookingRes.json();

      const checkoutRes = await fetch(
        `${API_BASE}/payments/stripe/checkout-session`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            booking_id: booking.id,
            accept_rules_and_gtc: acceptRules,
          }),
        }
      );

      if (!checkoutRes.ok) throw new Error(await checkoutRes.text());
      const checkout = await checkoutRes.json();

      if (!checkout.checkout_url) {
        throw new Error("Missing checkout_url from backend.");
      }

      window.location.href = checkout.checkout_url;
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  async function messageHost() {
    setError("");

    const token = getToken();
    if (!token) {
      router.push(`/login?next=/venues/${venue_id}`);
      return;
    }

    setBusy(true);

    try {
      const res = await fetch(`${API_BASE}/threads`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ venue_id }),
      });

      if (!res.ok) throw new Error(await res.text());
      const thread = await res.json();

      window.location.href = `/threads/${thread.id}`;
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  const isHost = Boolean(
    venue && me && venue.host_user_id && me.id === venue.host_user_id
  );

  const nights = nightsBetween(checkIn, checkOut);

  const netPerNight = venue?.payout_net_per_night ?? 0;
  const guestPerNight = guestPriceFromNet(netPerNight);
  const platformPerNight = guestPerNight - netPerNight;

  const guestTotal = guestPerNight * (nights || 0);
  const netTotal = netPerNight * (nights || 0);
  const platformTotal = platformPerNight * (nights || 0);

  const imageUrl = venue?.image_url ? `${API_BASE}${venue.image_url}` : null;

  return (
    <main
      style={{
        maxWidth: 1100,
        margin: "40px auto",
        padding: "0 20px",
        fontFamily: "system-ui",
      }}
    >
      <h1 style={{ marginTop: 0, marginBottom: 24 }}>Venue</h1>

      {venue ? (
        <div style={{ marginBottom: 14 }}>
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={venue.title}
              style={{
                width: "100%",
                maxHeight: 360,
                objectFit: "cover",
                borderRadius: 12,
                marginBottom: 16,
              }}
            />
          ) : null}

          <div>
            <b>{venue.title}</b>
          </div>
          <div>
            {venue.city} — cap {venue.capacity}
          </div>

          {(venue.venue_category || venue.venue_type) && (
            <div style={{ marginTop: 6, fontSize: 14, opacity: 0.85 }}>
              {venue.venue_category && (
                <div>
                  Category: <b>{venue.venue_category}</b>
                </div>
              )}
              {venue.venue_type && (
                <div>
                  Type: <b>{venue.venue_type}</b>
                </div>
              )}
            </div>
          )}

          <div
            style={{
              marginTop: 8,
              padding: 12,
              border: "1px solid #ddd",
              borderRadius: 8,
            }}
          >
            <div style={{ fontWeight: 600, marginBottom: 6 }}>Pricing</div>
            <div>
              Guest price per night (incl. 17% platform markup):{" "}
              <b>€{centsToEur(guestPerNight)}</b>
            </div>
            <div>Host net payout per night: €{centsToEur(netPerNight)}</div>
            <div>Platform fee per night: €{centsToEur(platformPerNight)}</div>
            <div style={{ marginTop: 6 }}>
              Minimum nights: <b>{venue.minimum_nights ?? 1}</b>
            </div>
            <div style={{ marginTop: 6 }}>
              Status: <b>{venue.status || "draft"}</b>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ marginBottom: 14, opacity: 0.8 }}>
          Venue ID: <code>{venue_id}</code>
        </div>
      )}

      {venue?.description ? (
        <div
          style={{
            marginBottom: 14,
            padding: 12,
            border: "1px solid #ddd",
            borderRadius: 8,
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Description</div>
          <div style={{ whiteSpace: "pre-wrap", fontSize: 14 }}>
            {venue.description}
          </div>
        </div>
      ) : null}

      {venue?.rules_and_restrictions ? (
        <div
          style={{
            marginBottom: 14,
            padding: 12,
            border: "1px solid #ddd",
            borderRadius: 8,
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: 6 }}>
            Rules & Restrictions
          </div>
          <div style={{ whiteSpace: "pre-wrap", fontSize: 14 }}>
            {venue.rules_and_restrictions}
          </div>
        </div>
      ) : null}

      {isHost ? (
        <div
          style={{
            marginBottom: 14,
            padding: 12,
            border: "1px solid #f0f0f0",
            borderRadius: 8,
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: 6 }}>Host tools</div>
          <a href={`/venues/${venue_id}/availability`}>Manage availability</a>
        </div>
      ) : null}

      {error ? (
        <div
          style={{
            color: "crimson",
            marginBottom: 12,
            whiteSpace: "pre-wrap",
          }}
        >
          {error}
        </div>
      ) : null}

      <div style={{ display: "flex", gap: 10, marginBottom: 18 }}>
        <button onClick={messageHost} disabled={busy} style={{ padding: 10 }}>
          {busy ? "Working..." : "Message host"}
        </button>
      </div>

      {!isHost && venue ? (
        <div style={{ display: "grid", gap: 10, maxWidth: 520 }}>
          <label>
            Check-in
            <input
              type="date"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
              style={{ width: "100%", padding: 10, marginTop: 6 }}
            />
          </label>

          <label>
            Check-out
            <input
              type="date"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
              style={{ width: "100%", padding: 10, marginTop: 6 }}
            />
          </label>

          <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
            <div style={{ fontWeight: 600, marginBottom: 6 }}>Summary</div>
            <div>Nights: {nights || 0}</div>
            <div style={{ marginTop: 6 }}>
              Guest total: <b>€{centsToEur(guestTotal)}</b>
            </div>
            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
              Includes platform fees. Host net for these dates: €
              {centsToEur(netTotal)} (platform: €{centsToEur(platformTotal)})
            </div>
          </div>

          <label
            style={{
              display: "flex",
              gap: 8,
              alignItems: "flex-start",
              fontSize: 13,
            }}
          >
            <input
              type="checkbox"
              checked={acceptRules}
              onChange={(e) => setAcceptRules(e.target.checked)}
              disabled={busy}
              style={{ marginTop: 3 }}
            />
            <span>I have read and accept venue rules + GTC.</span>
          </label>

          <button
            onClick={bookAndPay}
            disabled={busy || !acceptRules}
            style={{ padding: 10 }}
          >
            {busy ? "Starting checkout..." : "Book & pay"}
          </button>

          <div style={{ fontSize: 12, opacity: 0.7 }}>
            If you get “Dates are blocked by the host”, the host restricted
            availability.
          </div>
        </div>
      ) : null}
    </main>
  );
}