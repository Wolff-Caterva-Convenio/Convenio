"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";

const CATEGORY_TYPES = {
  "Art & Culture": [
    "Gallery",
    "Artist Studio",
    "Exhibition Space",
    "Residency Space",
    "Museum / Cultural Space",
    "Theater / Performance Space",
    "Rehearsal Space",
  ],
  "Events & Social": [
    "Event Venue",
    "Party Location",
    "Private Dining Space",
    "Rooftop Venue",
    "Bar / Club",
    "Lounge",
  ],
  "Creative Production": [
    "Photo Studio",
    "Filming Location",
    "Production Studio",
    "Podcast Studio",
    "Content Creation Studio",
    "Green Screen Studio",
    "Recording Studio",
  ],
  "Workshops & Education": [
    "Workshop Space",
    "Classroom",
    "Training Room",
    "Seminar Space",
    "Craft Studio",
    "Maker Space",
  ],
  "Professional / Business": [
    "Meeting Room",
    "Conference Venue",
    "Coworking Space",
    "Presentation Space",
    "Startup Hub",
    "Innovation Lab",
  ],
  "Community Spaces": [
    "Community Center",
    "Clubhouse",
    "Nonprofit Space",
    "Youth Center",
    "Social Club",
  ],
  "Unique Spaces": [
    "Industrial Loft",
    "Warehouse",
    "Historic Building",
    "Castle / Estate",
    "Architectural House",
    "Glass Pavilion",
    "Garden Venue",
    "Outdoor Venue",
  ],
};

function getVenueId(v) {
  return v?.id || v?.venue_id || null;
}

export default function HostVenuePage() {
  const params = useParams();
  const router = useRouter();
  const venue_id = params?.venue_id;

  const API_BASE = useMemo(
    () => process.env.NEXT_PUBLIC_API_BASE || "http://127.0.0.1:9000",
    []
  );

  const [venue, setVenue] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [city, setCity] = useState("");
  const [capacity, setCapacity] = useState("");
  const [savingDetails, setSavingDetails] = useState(false);

  const [category, setCategory] = useState("");
  const [type, setType] = useState("");

  const [priceEur, setPriceEur] = useState("");
  const [savingPrice, setSavingPrice] = useState(false);

  const [minNights, setMinNights] = useState("");
  const [savingMinNights, setSavingMinNights] = useState(false);

  const [rules, setRules] = useState("");
  const [savingRules, setSavingRules] = useState(false);

  const [selectedImage, setSelectedImage] = useState(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const [publishing, setPublishing] = useState(false);
  const [unpublishing, setUnpublishing] = useState(false);
  const [deleting, setDeleting] = useState(false);

  function getToken() {
    const token = localStorage.getItem("access_token");
    if (!token) throw new Error("Login required.");
    return token;
  }

  async function loadVenue() {
    setError("");
    setSuccess("");
    setVenue(null);

    if (!venue_id) return;

    const token = getToken();

    const meRes = await fetch(`${API_BASE}/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!meRes.ok) throw new Error(await meRes.text());
    const me = await meRes.json();

    const venuesRes = await fetch(`${API_BASE}/venues`);
    if (!venuesRes.ok) throw new Error(await venuesRes.text());
    const venues = await venuesRes.json();

    const found = Array.isArray(venues)
      ? venues.find((v) => String(getVenueId(v)) === String(venue_id))
      : null;

    if (!found) throw new Error(`Venue not found for id=${venue_id}.`);
    if (String(found.host_user_id) !== String(me.id)) {
      throw new Error("You do not own this venue.");
    }

    setVenue(found);
    setTitle(found.title || "");
    setDescription(found.description || "");
    setCity(found.city || "");
    setCapacity(String(found.capacity ?? ""));
    setCategory(found.venue_category || "");
    setType(found.venue_type || "");
    setPriceEur(((found.payout_net_per_night ?? 0) / 100).toFixed(2));
    setMinNights(String(found.minimum_nights ?? 1));
    setRules(found.rules_and_restrictions || "");
    setSelectedImage(null);
  }

  useEffect(() => {
    loadVenue().catch((e) => setError(e?.message || String(e)));
  }, [venue_id]);

  async function saveDetails() {
    setError("");
    setSuccess("");
    setSavingDetails(true);

    try {
      const token = getToken();
      const cap = Number(capacity);

      if (!title.trim()) throw new Error("Title is required.");
      if (!description.trim()) throw new Error("Description is required.");
      if (!city.trim()) throw new Error("City is required.");
      if (!Number.isInteger(cap) || cap < 1) {
        throw new Error("Capacity must be a whole number of at least 1.");
      }

      const res = await fetch(`${API_BASE}/venues/${venue_id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          city: city.trim(),
          capacity: cap,
          venue_category: category || null,
          venue_type: type || null,
          image_url: venue?.image_url || null,
        }),
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Basic details saved.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setSavingDetails(false);
    }
  }

  async function uploadImage() {
    setError("");
    setSuccess("");

    try {
      const token = getToken();

      if (!selectedImage) {
        throw new Error("Please choose an image first.");
      }

      const formData = new FormData();
      formData.append("image", selectedImage);

      setUploadingImage(true);

      const res = await fetch(`${API_BASE}/venues/${venue_id}/upload-image`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Image uploaded.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setUploadingImage(false);
    }
  }

  async function savePrice() {
    setError("");
    setSuccess("");
    setSavingPrice(true);

    try {
      const token = getToken();
      const eur = Number(priceEur);

      if (!Number.isFinite(eur)) {
        throw new Error("Price must be a number (e.g. 120 or 120.00).");
      }
      if (eur < 0) throw new Error("Price cannot be negative.");

      const res = await fetch(`${API_BASE}/venues/${venue_id}/price`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ price_eur: eur }),
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Price saved.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setSavingPrice(false);
    }
  }

  async function saveMinimumNights() {
    setError("");
    setSuccess("");
    setSavingMinNights(true);

    try {
      const token = getToken();
      const n = Number(minNights);

      if (!Number.isInteger(n)) {
        throw new Error("Minimum nights must be a whole number.");
      }
      if (n < 1) throw new Error("Minimum nights must be at least 1.");

      const res = await fetch(`${API_BASE}/venues/${venue_id}/minimum-nights`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ minimum_nights: n }),
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Minimum nights saved.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setSavingMinNights(false);
    }
  }

  async function saveRules() {
    setError("");
    setSuccess("");
    setSavingRules(true);

    try {
      const token = getToken();

      const res = await fetch(`${API_BASE}/venues/${venue_id}/rules`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ rules_and_restrictions: rules.trim() }),
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Rules saved.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setSavingRules(false);
    }
  }

  async function publishVenue() {
    setError("");
    setSuccess("");
    setPublishing(true);

    try {
      const token = getToken();

      const res = await fetch(`${API_BASE}/venues/${venue_id}/publish`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Venue published.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setPublishing(false);
    }
  }

  async function unpublishVenue() {
    setError("");
    setSuccess("");
    setUnpublishing(true);

    try {
      const token = getToken();

      const res = await fetch(`${API_BASE}/venues/${venue_id}/unpublish`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error(await res.text());

      setSuccess("Venue unpublished and moved back to draft.");
      await loadVenue();
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setUnpublishing(false);
    }
  }

  async function deleteVenue() {
    const ok = window.confirm(
      "Delete this venue?\n\nThis only works if the venue has no bookings."
    );
    if (!ok) return;

    setError("");
    setSuccess("");
    setDeleting(true);

    try {
      const token = getToken();

      const res = await fetch(`${API_BASE}/venues/${venue_id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error(await res.text());

      router.push("/my-venues");
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setDeleting(false);
    }
  }

  if (!venue_id) {
    return (
      <main style={{ fontFamily: "system-ui", padding: 24, maxWidth: 900, margin: "0 auto" }}>
        <div>Loading route…</div>
      </main>
    );
  }

  if (error && !venue) {
    return (
      <main style={{ fontFamily: "system-ui", padding: 24, maxWidth: 900, margin: "0 auto" }}>
        <h2>Error</h2>
        <div style={{ color: "crimson", whiteSpace: "pre-wrap" }}>{error}</div>
        <div style={{ marginTop: 12 }}>
          <a href="/my-venues">← Back to My venues</a>
        </div>
      </main>
    );
  }

  if (!venue) {
    return (
      <main style={{ fontFamily: "system-ui", padding: 24, maxWidth: 900, margin: "0 auto" }}>
        <div>Loading venue…</div>
      </main>
    );
  }

  const vid = getVenueId(venue);
  const availableTypes = category ? CATEGORY_TYPES[category] : [];

  return (
    <main style={{ fontFamily: "system-ui", padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1>Manage venue</h1>

      <div style={{ marginBottom: 16 }}>
        <a href="/my-venues">← Back to My venues</a>
      </div>

      {error ? (
        <div style={{ color: "crimson", marginBottom: 12, whiteSpace: "pre-wrap" }}>
          {error}
        </div>
      ) : null}

      {success ? (
        <div style={{ color: "green", marginBottom: 12, whiteSpace: "pre-wrap" }}>
          {success}
        </div>
      ) : null}

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        {venue.image_url ? (
          <img
            src={venue.image_url}
            alt={venue.title}
            style={{
              width: "100%",
              maxHeight: 280,
              objectFit: "cover",
              borderRadius: 10,
              marginBottom: 14,
            }}
          />
        ) : null}

        <h2 style={{ marginTop: 0 }}>{venue.title}</h2>
        <div>{venue.description}</div>
        <div style={{ marginTop: 6 }}>{venue.city}</div>
        <div>Capacity: {venue.capacity}</div>
        <div style={{ marginTop: 10 }}>
          Current price/night: <b>€{((venue.payout_net_per_night ?? 0) / 100).toFixed(2)}</b>
        </div>
        <div style={{ marginTop: 6 }}>
          Current minimum nights: <b>{venue.minimum_nights ?? 1}</b>
        </div>
        <div style={{ marginTop: 6 }}>
          Category: <b>{venue.venue_category || "—"}</b>
        </div>
        <div style={{ marginTop: 6 }}>
          Type: <b>{venue.venue_type || "—"}</b>
        </div>
        <div style={{ marginTop: 6 }}>
          Status: <b>{venue.status || "draft"}</b>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Edit basic details</h3>
        <div style={{ display: "grid", gap: 12 }}>
          <label>
            Title
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            />
          </label>

          <label>
            Description
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            />
          </label>

          <label>
            City
            <input
              value={city}
              onChange={(e) => setCity(e.target.value)}
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            />
          </label>

          <label>
            Capacity
            <input
              value={capacity}
              onChange={(e) => setCapacity(e.target.value)}
              inputMode="numeric"
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            />
          </label>

          <label>
            Category
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setType("");
              }}
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            >
              <option value="">Select category</option>
              {Object.keys(CATEGORY_TYPES).map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label>
            Venue type
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              disabled={!category}
              style={{ display: "block", width: "100%", padding: 8, boxSizing: "border-box", marginTop: 4 }}
            >
              <option value="">
                {category ? "Select type" : "Select category first"}
              </option>
              {availableTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </label>

          <div>
            <button
              onClick={saveDetails}
              disabled={savingDetails}
              style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
            >
              {savingDetails ? "Saving..." : "Save details"}
            </button>
          </div>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Venue image</h3>
        <div style={{ marginBottom: 12, opacity: 0.8 }}>
          Upload one JPG, PNG, or WEBP image (max 5 MB).
        </div>

        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(e) => setSelectedImage(e.target.files?.[0] || null)}
          style={{ marginBottom: 12 }}
        />

        <div>
          <button
            onClick={uploadImage}
            disabled={uploadingImage || !selectedImage}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {uploadingImage ? "Uploading..." : "Upload image"}
          </button>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Edit price per night</h3>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <label>
            €{" "}
            <input
              value={priceEur}
              onChange={(e) => setPriceEur(e.target.value)}
              style={{ padding: 6, width: 140 }}
              inputMode="decimal"
            />
          </label>
          <button
            onClick={savePrice}
            disabled={savingPrice}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {savingPrice ? "Saving..." : "Save price"}
          </button>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Minimum booking duration</h3>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <label>
            Nights{" "}
            <input
              value={minNights}
              onChange={(e) => setMinNights(e.target.value)}
              style={{ padding: 6, width: 90 }}
              inputMode="numeric"
            />
          </label>
          <button
            onClick={saveMinimumNights}
            disabled={savingMinNights}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {savingMinNights ? "Saving..." : "Save minimum nights"}
          </button>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Rules & restrictions</h3>
        <div style={{ marginBottom: 12, opacity: 0.8 }}>
          Rules are required before publishing.
        </div>
        <textarea
          value={rules}
          onChange={(e) => setRules(e.target.value)}
          rows={7}
          placeholder="Enter your venue rules here..."
          style={{ width: "100%", padding: 8, boxSizing: "border-box", marginBottom: 12 }}
        />
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button
            onClick={saveRules}
            disabled={savingRules}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {savingRules ? "Saving..." : "Save rules"}
          </button>
          <button
            onClick={publishVenue}
            disabled={publishing}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {publishing ? "Publishing..." : "Publish venue"}
          </button>
          <button
            onClick={unpublishVenue}
            disabled={unpublishing}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
          >
            {unpublishing ? "Unpublishing..." : "Unpublish venue"}
          </button>
        </div>
      </div>

      <div style={{ border: "1px solid #ddd", padding: 16, borderRadius: 10, marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Danger zone</h3>
        <div style={{ marginBottom: 12, color: "#555" }}>
          Delete only works if the venue has no bookings.
        </div>
        <button
          onClick={deleteVenue}
          disabled={deleting}
          style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", background: "white" }}
        >
          {deleting ? "Deleting..." : "Delete venue"}
        </button>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <a
          href={`/venues/${vid}/availability`}
          style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", textDecoration: "none" }}
        >
          Manage availability
        </a>
        <a
          href={`/my-venues/bookings`}
          style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", textDecoration: "none" }}
        >
          View all bookings
        </a>
        <a
          href={`/venues/${vid}`}
          style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", textDecoration: "none" }}
        >
          View listing
        </a>
      </div>
    </main>
  );
}